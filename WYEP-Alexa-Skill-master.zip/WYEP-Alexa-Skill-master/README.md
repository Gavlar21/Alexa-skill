# WYEP-Alexa-Skill
This Alexa skill plays the WYEP FM live AAC radio stream, and tells you the title and artist of the song now playing.

Commands:  
Open y. e. p. (plays stream)  
Ask y. e. p. what song this is  
stop  
resume  
pause (stops)  
